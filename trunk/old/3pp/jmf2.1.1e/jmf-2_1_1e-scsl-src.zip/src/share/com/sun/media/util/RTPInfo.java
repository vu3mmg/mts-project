/*
 * @(#)RTPInfo.java	1.2 02/08/21
 *
 * Copyright (c) 1996-2002 Sun Microsystems, Inc.  All rights reserved.
 */

package com.sun.media.util;


/**
 * A utility class to keep track of the passage of time as data
 * buffers are being processed.
 */
public interface RTPInfo {

    public String getCNAME();

}


